Isabella Rhee - 'CMU Buggy Racer' Term Project 2020

Cmu buggy racers is a 3rd person racing game that includes features such as 
random track generation, opponent AI, and side scrolling. Players will be able 
to use the keyboard to “race” their buggies around a track. Edges of the track 
and other obstacles will slow them down while staying on the track will increase
speed as the player presses the arrow keys. Players can choose their car color 
and input their name to be displayed above their car. 

In order to run this program
the user must have the PIL/pillow module. This can be done using these instructions
from http://www.cs.cmu.edu/~112/notes/notes-animations-part3.html

Also, playsound must be installed for the music using the commands:
(from https://stackoverflow.com/questions/47270354/python-3-no-module-named-appkit
and https://pypi.org/project/playsound/)

pip (or pip3) install playsound
pip (or pip3) pip3 install -U PyObjC

After this is installed, all you need to do is run the "CMUBuggyRacer.py" file.
The rest of the python files needed are in this folder.