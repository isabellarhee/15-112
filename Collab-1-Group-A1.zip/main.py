#Team: Violet Chen (tanshic), Annie Wu (anniew), Isabella Rhee (irhee)

import turtle
import string
import standard_problem
print(standard_problem.testIsPerfectSquare())

#Turtle puzzle 1

def appStarted():
    screen = turtle.Screen()
    winTop = screen.window_height()//2
    drawText('Turtle Puzzle 1', 0, winTop - 40)
    drawText('Click the mouse!', 0, winTop - 65, size=20)
    drawText('Gold dots on top and bottom, navy dots on the sides!',
             0, winTop - 90, size=20)
    drawX()
    turtle.hideturtle()
      
def drawX(): #draw two lines from corner to corner
    turtle.penup()
    turtle.goto(-800, 600)
    turtle.pendown()
    turtle.goto(800,-600)
    turtle.penup()
    turtle.goto(800,600)
    turtle.pendown()
    turtle.goto(-800,-600)
    turtle.penup()

def mousePressed(x,y):
    if (y/x < .75 and y/x > -.75): #slope of da lines 
      turtle.color("navy")
      turtle.goto(x,y)
      turtle.dot(20)
    else:
      turtle.color("gold")
      turtle.goto(x,y)
      turtle.dot(20)

#Turtle Puzzle 2-------------------------------

# def appStarted():
#     screen = turtle.Screen()
#     winTop = screen.window_height()//2
#     drawText('Turtle Puzzle 2', 0, winTop - 40)
#     drawText('Click the mouse!', 0, winTop - 65, size=20)
#     drawText('Turtle moves halfway towards click!',
#              0, winTop - 90, size=20)
#     drawText('Click on the last-drawn dot to reset!',
#              0, winTop - 115, size=20)
#     turtle.pensize(8)

# def mousePressed(x,y):
#     x1,y1=turtle.position()
#     turtle.color('black')
#     turtle.goto((x+x1)/2, (y+y1)/2)
#     turtle.dot(20)
#     distanceToCenter=((x-x1)**2+(y-y1)**2)**0.5
#     if (distanceToCenter<=20):
#       turtle.clear()
#       turtle.penup()
#       turtle.goto(0, 0)
#       turtle.pendown()
#       appStarted()

#Turtle Puzzle 3-------------------------------------

# def triangle(x, y):
#     turtle.goto(x, y-9)
#     turtle.pendown()
#     turtle.goto(x+24, y+9)
#     turtle.goto(x-24, y+9)
#     turtle.goto(x, y-9)
#     turtle.penup()

# def mousePressed(x,y):
#     screen = turtle.Screen()
#     diagonal = ((screen.window_height())**2 + (screen.window_width())**2)**0.5
#     distanceToCenter = (x**2 + y**2)**0.5
#     turtle.goto(x,y)
#     n = diagonal/2
#     r = 1-(distanceToCenter/n)
#     g = 1-(distanceToCenter/n)
#     b = 1-(distanceToCenter/n)
#     turtle.color(r, g, b)
#     triangle(x, y)

# def appStarted():
#     screen = turtle.Screen()
#     winTop = screen.window_height()//2
#     drawText('Turtle Puzzle 3', 0, winTop - 40)
#     drawText('Click the mouse!', 0, winTop - 65, size=20)
#     drawText('White triangles near center, darker as you move away!', 0, winTop - 90, size=20)
#     turtle.penup()
#     turtle.color('blue')
#     turtle.dot(20)
#     turtle.pensize(10)
#     turtle.hideturtle()

#Our Custom Turtle Puzzle--------------------------------------
#youtube link:
#https://youtu.be/y22fZqarxUk

# def appStarted():
#     screen = turtle.Screen()
#     winTop = screen.window_height()//2
#     drawText('Group A1', 0, winTop - 40)
#     drawText('Click the mouse to draw a line!', 0, winTop - 65, size=20)
#     drawText('See the equation. Click the top to clear!', 0, winTop - 90, size=20)
#     turtle.penup()
#     turtle.goto(0, screen.window_height())
#     turtle.pendown()
#     turtle.goto(0, -screen.window_height())
#     turtle.penup()
#     turtle.goto(-screen.window_width(),0)
#     turtle.pendown()
#     turtle.goto(screen.window_width(), 0)
    
# def mousePressed(x,y):
#     screen = turtle.Screen()
#     winTop = screen.window_height()//2
#     turtle.pensize(5)
#     turtle.penup()
#     turtle.goto(0,0)
#     turtle.pendown()
#     turtle.goto(x,y)
#     turtle.dot(20)
#     print(x,y)
#     k=y/x
#     eqn=('y='+str(round(k,2))+'x')
#     drawText(eqn, x-30, y+40, size=20)
#     if (y >= winTop - 90):
#         turtle.clear()
#         turtle.penup()
#         turtle.goto(0, 0)
#         turtle.pendown()
#         appStarted()
    
# Group A3 puzzle tic-tac-toe-----------------------------

# def appStarted():
#     turtle.color("Black")
#     screen = turtle.Screen()
#     winTop = screen.window_height()//2
#     drawText('Tic Tac Toe Board', 0, winTop - 40)
#     drawText('Orange and Blue Players', 0, winTop - 65,size=20)
#     drawText('Click on "Tic Tac Toe Board" to Reset', 0, winTop - 90, size=20)
#     turtle.penup()
#     turtle.goto(-350,-100)
#     turtle.pendown()
#     turtle.goto (350,-100)
#     turtle.penup()
#     turtle.goto (-350, 100)
#     turtle.pendown()
#     turtle.goto (350, 100)
#     turtle.penup()
#     turtle.goto (-120, 250)
#     turtle.pendown()
#     turtle.goto(-120, -250)
#     turtle.penup()
#     turtle.goto(120, 250)
#     turtle.pendown()
#     turtle.goto(120,-250)
#     turtle.penup()
#     turtle.hideturtle()
#     turtle.n = 0
  
# def mousePressed(x,y):
#     turtle.n += 1
#     screen = turtle.Screen()
#     winTop = screen.window_height()//2
#     if (y >= winTop - 40):
#       turtle.clear()
#       turtle.penup()
#       turtle.goto(0, 0)
#       turtle.pendown()
#       appStarted()
#     elif (turtle.n%2==0):
#       turtle.color("Blue")
#       turtle.goto(x, y)
#       turtle.dot(20)
#     else:
#       turtle.color("Orange")
#       turtle.goto(x, y)
#       turtle.dot(20)
    
#Group A2 puzzle----------------------------------

# def appStarted():
#     screen = turtle.Screen()
#     winTop = screen.window_height()//2
#     drawText('Turtle Puzzle Fun', 0, winTop - 40)
#     drawText('Click the mouse!', 0, winTop - 65, size=20)
#     drawText('Turtle Changes Shape!', 0, winTop - 90, size=20)
#     turtle.hideturtle()
#     turtle.pensize(10)
#     turtle.color('Purple')
#     turtle.penup()
#     turtle.goto(0, 0)
#     turtle.pendown()
#     turtle.goto(400, 0)
#     turtle.penup()
#     turtle.goto(0,0)
#     turtle.pendown()
#     turtle.goto(-400, 0)
#     turtle.penup()
#     turtle.goto(0,0)
#     turtle.pendown()
#     turtle.goto(0, 300)
#     turtle.penup()
#     turtle.goto(0,0)
#     turtle.pendown()
#     turtle.goto(0, -300)

# def mousePressed(x, y):
#     turtle.penup()
#     if (x > 0) and (y > 0):
#       triangle(x, y)
#     elif (x < 0) and (y > 0):
#       square(x, y)
#     elif (x < 0) and (y < 0):
#       pentagon(x, y)
#     elif (x > 0) and (y < 0):
#       turtle.goto(x, y)
#       turtle.pendown()
#       turtle.circle(15)

# def triangle(x, y):
#     turtle.goto(x+24, y+15)
#     turtle.pendown()
#     turtle.goto(x-24, y+15)
#     turtle.goto(x, y-15)
#     turtle.goto(x, y-15)
#     turtle.goto(x+24, y+15)
#     turtle.penup()

# def square(x, y):
#     turtle.goto(x+15, y-15)
#     turtle.pendown()
#     turtle.goto(x+15, y+15)
#     turtle.goto(x-15, y+15)
#     turtle.goto(x-15, y-15)
#     turtle.goto(x+15, y-15)
#     turtle.penup()

# def pentagon(x, y):
#     turtle.goto(x, y-20)
#     turtle.pendown()
#     turtle.goto(x-20, y-6)
#     turtle.goto(x-12, y+16)
#     turtle.goto(x+12, y+16)
#     turtle.goto(x+20, y-6)
#     turtle.goto(x, y-20)
#     turtle.penup()

def drawText(label, x, y, font='Arial', size=30, style='bold', align='center'):
    oldx, oldy = turtle.position()
    turtle.penup()
    turtle.goto(x, y)
    turtle.write(label, font=(font, size, style), align=align)
    turtle.goto(oldx, oldy)
    turtle.pendown()

def main(winWidth, winHeight, bgColor):
    screen = turtle.Screen()
    turtle.speed(0)
    turtle.setup(width=winWidth, height=winHeight)
    screen.bgcolor(bgColor)
    appStarted()
    turtle.speed(10)
    def safeCall(fnName, *args):
        if (fnName in globals()):
            globals()[fnName](*args)
    def keyPressedWrapper(key):
        if (len(key) > 1): key = key.capitalize()
        safeCall('keyPressed', key)
    def bindKey(key):
        if (len(key) > 1) or (ord(key) > 32):
          screen.onkey(lambda: keyPressedWrapper(key), key)
    keys = (['Up', 'Down', 'Left', 'Right', 'space', 'Tab', 'Return'] + 
          list(string.ascii_letters + string.digits))
    for key in keys:
        bindKey(key)
    screen.listen()
    screen.onclick(lambda x, y: safeCall('mousePressed', x, y))
    screen.mainloop()

main(800, 600, 'lightgreen')